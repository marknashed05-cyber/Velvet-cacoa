export default {content:['./index.html','./src/**/*.{js,ts,jsx,tsx}'],theme:{extend:{colors:{cocoa:{dark:'#2C1D11',DEFAULT:'#4A2E1B',light:'#8C5A3C',accent:'#D4AF37'},cream:'#FDFBF7'}}},plugins:[]};
