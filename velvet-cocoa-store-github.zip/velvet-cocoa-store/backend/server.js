const express=require('express');const mongoose=require('mongoose');const cors=require('cors');require('dotenv').config();
const app=express();app.use(cors({origin:process.env.CLIENT_URL||true}));app.use(express.json());
app.get('/',(q,s)=>s.json({message:'Velvet & Cocoa API is running'}));app.get('/api/health',(q,s)=>s.json({ok:true}));
app.use('/api/auth',require('./routes/auth'));app.use('/api/products',require('./routes/products'));app.use('/api/orders',require('./routes/orders'));
const PORT=process.env.PORT||5000;mongoose.connect(process.env.MONGO_URI).then(()=>app.listen(PORT,()=>console.log(`Server running on ${PORT}`))).catch(e=>{console.error(e);process.exit(1)});
